const CISA_LESSON_MODULE = {};

CISA_LESSON_MODULE.getString = function (key) {
    let values = {};

    values['cybertitle'] = 'Cyber Dashboard';
    values['cyberresourceshead'] = 'Resources';
    values['cyberstatushead'] = 'Status';
    values['cyberactionhead'] = 'Student Action';
    values['cyberstatusrunning'] = 'Running';
    values['cyberstatusinitializing'] = 'Initializing';
    values['cyberactionlaunch'] = 'Launch in Cyber Range';
    values['cybericonnetwork'] = 'networking component';
    values['cybericonserver'] = 'server component';
    values['cybericonworkstation'] = 'workstation component';

    return values[key] ?? 'Key Not found';
}

CISA_LESSON_MODULE.init = function (Y) {


    function styleCyberRow(resource) {
        let iconClass;
        let type = resource["type"].toUpperCase();
        switch (type) {
            case "NETWORK":
                iconClass = "connectdevelop"; //there is a network-wired in FA 5
                break;
            case "SERVER":
                iconClass = "server";
                break;
            case "WORKSTATION":
                iconClass = "desktop";
                break;
            default:
                iconClass = "question-circle" //unknown resource type
                break;
        }

        let statusClass;
        var avail = false;

        switch (resource["status"]) {
            case "PROVISIONED":
            case "RUNNING":
                avail = true;
                resource['status'] = 'Running';
                statusClass = "rowgreen";
                break;
            case "REQUESTED":
            case "INITIALIZING":
                avail = false;
                resource['status'] = 'Initializing'
                statusClass = "rowdefault";
                break;
            default:
                avail = false;
                resource['status'] = 'Stopped'
                statusClass = "rowdefault";
        }

        let link;

        if (resource["link"] && avail) {
            link = `<a href='${resource["link"]}' class='rowlink' target='_blank'>Launch in Cyber Range</a>`;
        } else {
            link = `<a class='rowdisable'>Launch in Cyber Range</a>`;
        }

        return `
                     <tr class="lastrow">
                          <td class="cell c0" ><span class="resourcename"><i class="icon fa fa-${iconClass} fa-fw"
                          title="${type.toLowerCase()} component" aria-label="${type.toLowerCase()} component"></i>${resource.name}</span></td>
                          <td class="cell c1" >${link}</td>
                          <td class="cell c2 lastcol" ><span class=${statusClass}>${resource.status}</span></td>
                      </tr>`;
    }

    document.addEventListener("DOMContentLoaded", (event) => {
        var interval = null;
        const POLL_INTERVAL = 15000; //15 seconds

        //when the page changes, clear the interval
        window.addEventListener("hashchange", (event) => {
            clearInterval(interval);
        });

        require(["core/ajax"], function (ajax) {
            //function to perform after resource fetch
            let updateResourceTable = (data) => {
                var resourceTable = document.getElementById("lesson_resource_table");
                var newHtml = ``;

                data.forEach((d, i) => {
                    let last = i === d.length - 1;
                    newHtml += styleCyberRow(d);
                });
                resourceTable.innerHTML = newHtml;
            };

            let showErrorMessage = (error) => {
                let resourceTable = document.getElementById("lesson_resource_table");
                
                let html = 
                `<tr class="lastrow">
                <td class="cell c0" >
                <i class="fa fa-exclamation-triangle" aria-hidden="true"></i> ${error.message ?? error} </td>
                <td class="cell c1"></td>
                <td class="cell c2"></td>
                </tr>`;

                resourceTable.innerHTML = html;


            }
            //function to fetch resources each time
            let getResources = (initial = false) => {
                ajax.call([
                    {
                        methodname: "mod_cisalesson_get_lesson_resources",
                        args: {},
                        done: (data) => {

                            updateResourceTable(data);

                            //move this here
                            //only start the polling if there was not an error
                            //and it's the initial load
                            if (initial === true) {
                                clearInterval(interval)
                                interval = setInterval(() => {
                                    getResources();
                                }, POLL_INTERVAL);
                            }

                        },
                        fail: (ex) => {
                            showErrorMessage(ex);
                            //clear the interval, no need to keep it going
                            clearInterval(interval)
                        },
                    },
                ]);


            };

            getResources(true);


        });
    });
};
