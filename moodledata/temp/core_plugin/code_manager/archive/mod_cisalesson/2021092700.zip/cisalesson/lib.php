<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Standard library of functions and constants for lesson
 *
 * @package mod_cisalesson
 * @copyright  1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

defined('MOODLE_INTERNAL') || die();

// Event types.
define('CISALESSON_EVENT_TYPE_OPEN', 'open');
define('CISALESSON_EVENT_TYPE_CLOSE', 'close');

/* Do not include any libraries here! */

/**
 * Given an object containing all the necessary data,
 * (defined by the form in mod_form.php) this function
 * will create a new instance and return the id number
 * of the new instance.
 *
 * @global object
 * @global object
 * @param object $cisalesson Lesson post data from the form
 * @return int
 **/
function cisalesson_add_instance($data, $mform) {
    global $DB;

    $cmid = $data->coursemodule;
    $draftitemid = $data->mediafile;
    $context = context_module::instance($cmid);

    cisalesson_process_pre_save($data);

    unset($data->mediafile);
    $cisalessonid = $DB->insert_record("cisalesson", $data);
    $data->id = $cisalessonid;

    cisalesson_update_media_file($cisalessonid, $context, $draftitemid);

    cisalesson_process_post_save($data);

    cisalesson_grade_item_update($data);

    return $cisalessonid;
}

/**
 * Given an object containing all the necessary data,
 * (defined by the form in mod_form.php) this function
 * will update an existing instance with new data.
 *
 * @global object
 * @param object $cisalesson Lesson post data from the form
 * @return boolean
 **/
function cisalesson_update_instance($data, $mform) {
    global $DB;

    $data->id = $data->instance;
    $cmid = $data->coursemodule;
    $draftitemid = $data->mediafile;
    $context = context_module::instance($cmid);

    cisalesson_process_pre_save($data);

    unset($data->mediafile);
    $DB->update_record("cisalesson", $data);

    cisalesson_update_media_file($data->id, $context, $draftitemid);

    cisalesson_process_post_save($data);

    // update grade item definition
    cisalesson_grade_item_update($data);

    // update grades - TODO: do it only when grading style changes
    cisalesson_update_grades($data, 0, false);

    return true;
}

/**
 * This function updates the events associated to the lesson.
 * If $override is non-zero, then it updates only the events
 * associated with the specified override.
 *
 * @uses CISALESSON_MAX_EVENT_LENGTH
 * @param object $cisalesson the lesson object.
 * @param object $override (optional) limit to a specific override
 */
function cisalesson_update_events($cisalesson, $override = null) {
    global $CFG, $DB;

    require_once($CFG->dirroot . '/mod/cisalesson/locallib.php');
    require_once($CFG->dirroot . '/calendar/lib.php');

    // Load the old events relating to this lesson.
    $conds = array('modulename' => 'cisalesson',
                   'instance' => $cisalesson->id);
    if (!empty($override)) {
        // Only load events for this override.
        if (isset($override->userid)) {
            $conds['userid'] = $override->userid;
        } else {
            $conds['groupid'] = $override->groupid;
        }
    }
    $oldevents = $DB->get_records('event', $conds, 'id ASC');

    // Now make a to-do list of all that needs to be updated.
    if (empty($override)) {
        // We are updating the primary settings for the lesson, so we need to add all the overrides.
        $overrides = $DB->get_records('cisalesson_overrides', array('lessonid' => $cisalesson->id), 'id ASC');
        // It is necessary to add an empty stdClass to the beginning of the array as the $oldevents
        // list contains the original (non-override) event for the module. If this is not included
        // the logic below will end up updating the wrong row when we try to reconcile this $overrides
        // list against the $oldevents list.
        array_unshift($overrides, new stdClass());
    } else {
        // Just do the one override.
        $overrides = array($override);
    }

    // Get group override priorities.
    $grouppriorities = cisalesson_get_group_override_priorities($cisalesson->id);

    foreach ($overrides as $current) {
        $groupid   = isset($current->groupid) ? $current->groupid : 0;
        $userid    = isset($current->userid) ? $current->userid : 0;
        $available  = isset($current->available) ? $current->available : $cisalesson->available;
        $deadline = isset($current->deadline) ? $current->deadline : $cisalesson->deadline;

        // Only add open/close events for an override if they differ from the lesson default.
        $addopen  = empty($current->id) || !empty($current->available);
        $addclose = empty($current->id) || !empty($current->deadline);

        if (!empty($cisalesson->coursemodule)) {
            $cmid = $cisalesson->coursemodule;
        } else {
            $cmid = get_coursemodule_from_instance('cisalesson', $cisalesson->id, $cisalesson->course)->id;
        }

        $event = new stdClass();
        $event->type = !$deadline ? CALENDAR_EVENT_TYPE_ACTION : CALENDAR_EVENT_TYPE_STANDARD;
        $event->description = format_module_intro('cisalesson', $cisalesson, $cmid, false);
        $event->format = FORMAT_HTML;
        // Events module won't show user events when the courseid is nonzero.
        $event->courseid    = ($userid) ? 0 : $cisalesson->course;
        $event->groupid     = $groupid;
        $event->userid      = $userid;
        $event->modulename  = 'cisalesson';
        $event->instance    = $cisalesson->id;
        $event->timestart   = $available;
        $event->timeduration = max($deadline - $available, 0);
        $event->timesort    = $available;
        $event->visible     = instance_is_visible('cisalesson', $cisalesson);
        $event->eventtype   = CISALESSON_EVENT_TYPE_OPEN;
        $event->priority    = null;

        // Determine the event name and priority.
        if ($groupid) {
            // Group override event.
            $params = new stdClass();
            $params->cisalesson = $cisalesson->name;
            $params->group = groups_get_group_name($groupid);
            if ($params->group === false) {
                // Group doesn't exist, just skip it.
                continue;
            }
            $eventname = get_string('overridegroupeventname', 'cisalesson', $params);
            // Set group override priority.
            if ($grouppriorities !== null) {
                $openpriorities = $grouppriorities['open'];
                if (isset($openpriorities[$available])) {
                    $event->priority = $openpriorities[$available];
                }
            }
        } else if ($userid) {
            // User override event.
            $params = new stdClass();
            $params->cisalesson = $cisalesson->name;
            $eventname = get_string('overrideusereventname', 'cisalesson', $params);
            // Set user override priority.
            $event->priority = CALENDAR_EVENT_USER_OVERRIDE_PRIORITY;
        } else {
            // The parent event.
            $eventname = $cisalesson->name;
        }

        if ($addopen or $addclose) {
            // Separate start and end events.
            $event->timeduration  = 0;
            if ($available && $addopen) {
                if ($oldevent = array_shift($oldevents)) {
                    $event->id = $oldevent->id;
                } else {
                    unset($event->id);
                }
                $event->name = get_string('lessoneventopens', 'cisalesson', $eventname);
                // The method calendar_event::create will reuse a db record if the id field is set.
                calendar_event::create($event, false);
            }
            if ($deadline && $addclose) {
                if ($oldevent = array_shift($oldevents)) {
                    $event->id = $oldevent->id;
                } else {
                    unset($event->id);
                }
                $event->type      = CALENDAR_EVENT_TYPE_ACTION;
                $event->name      = get_string('lessoneventcloses', 'cisalesson', $eventname);
                $event->timestart = $deadline;
                $event->timesort  = $deadline;
                $event->eventtype = CISALESSON_EVENT_TYPE_CLOSE;
                if ($groupid && $grouppriorities !== null) {
                    $closepriorities = $grouppriorities['close'];
                    if (isset($closepriorities[$deadline])) {
                        $event->priority = $closepriorities[$deadline];
                    }
                }
                calendar_event::create($event, false);
            }
        }
    }

    // Delete any leftover events.
    foreach ($oldevents as $badevent) {
        $badevent = calendar_event::load($badevent);
        $badevent->delete();
    }
}

/**
 * Calculates the priorities of timeopen and timeclose values for group overrides for a lesson.
 *
 * @param int $cisalessonid The lesson ID.
 * @return array|null Array of group override priorities for open and close times. Null if there are no group overrides.
 */
function cisalesson_get_group_override_priorities($cisalessonid) {
    global $DB;

    // Fetch group overrides.
    $where = 'lessonid = :lessonid AND groupid IS NOT NULL';
    $params = ['lessonid' => $cisalessonid];
    $overrides = $DB->get_records_select('cisalesson_overrides', $where, $params, '', 'id, groupid, available, deadline');
    if (!$overrides) {
        return null;
    }

    $grouptimeopen = [];
    $grouptimeclose = [];
    foreach ($overrides as $override) {
        if ($override->available !== null && !in_array($override->available, $grouptimeopen)) {
            $grouptimeopen[] = $override->available;
        }
        if ($override->deadline !== null && !in_array($override->deadline, $grouptimeclose)) {
            $grouptimeclose[] = $override->deadline;
        }
    }

    // Sort open times in ascending manner. The earlier open time gets higher priority.
    sort($grouptimeopen);
    // Set priorities.
    $opengrouppriorities = [];
    $openpriority = 1;
    foreach ($grouptimeopen as $timeopen) {
        $opengrouppriorities[$timeopen] = $openpriority++;
    }

    // Sort close times in descending manner. The later close time gets higher priority.
    rsort($grouptimeclose);
    // Set priorities.
    $closegrouppriorities = [];
    $closepriority = 1;
    foreach ($grouptimeclose as $timeclose) {
        $closegrouppriorities[$timeclose] = $closepriority++;
    }

    return [
        'open' => $opengrouppriorities,
        'close' => $closegrouppriorities
    ];
}

/**
 * This standard function will check all instances of this module
 * and make sure there are up-to-date events created for each of them.
 * If courseid = 0, then every lesson event in the site is checked, else
 * only lesson events belonging to the course specified are checked.
 * This function is used, in its new format, by restore_refresh_events()
 *
 * @param int $courseid
 * @param int|stdClass $instance Lesson module instance or ID.
 * @param int|stdClass $cm Course module object or ID (not used in this module).
 * @return bool
 */
function cisalesson_refresh_events($courseid = 0, $instance = null, $cm = null) {
    global $DB;

    // If we have instance information then we can just update the one event instead of updating all events.
    if (isset($instance)) {
        if (!is_object($instance)) {
            $instance = $DB->get_record('cisalesson', array('id' => $instance), '*', MUST_EXIST);
        }
        cisalesson_update_events($instance);
        return true;
    }

    if ($courseid == 0) {
        if (!$cisalessons = $DB->get_records('cisalesson')) {
            return true;
        }
    } else {
        if (!$cisalessons = $DB->get_records('cisalesson', array('course' => $courseid))) {
            return true;
        }
    }

    foreach ($cisalessons as $cisalesson) {
        cisalesson_update_events($cisalesson);
    }

    return true;
}

/**
 * Given an ID of an instance of this module,
 * this function will permanently delete the instance
 * and any data that depends on it.
 *
 * @global object
 * @param int $id
 * @return bool
 */
function cisalesson_delete_instance($id) {
    global $DB, $CFG;
    require_once($CFG->dirroot . '/mod/cisalesson/locallib.php');

    $cisalesson = $DB->get_record("cisalesson", array("id"=>$id), '*', MUST_EXIST);
    $cisalesson = new cisalesson($cisalesson);
    return $cisalesson->delete();
}

/**
 * Return a small object with summary information about what a
 * user has done with a given particular instance of this module
 * Used for user activity reports.
 * $return->time = the time they did it
 * $return->info = a short text description
 *
 * @global object
 * @param object $course
 * @param object $user
 * @param object $mod
 * @param object $cisalesson
 * @return object
 */
function cisalesson_user_outline($course, $user, $mod, $cisalesson) {
    global $CFG, $DB;

    require_once("$CFG->libdir/gradelib.php");
    $grades = grade_get_grades($course->id, 'mod', 'cisalesson', $cisalesson->id, $user->id);
    $return = new stdClass();

    if (empty($grades->items[0]->grades)) {
        $return->info = get_string("nolessonattempts", "cisalesson");
    } else {
        $grade = reset($grades->items[0]->grades);
        if (empty($grade->grade)) {

            // Check to see if it an ungraded / incomplete attempt.
            $sql = "SELECT *
                      FROM {cisalesson_timer}
                     WHERE lessonid = :lessonid
                       AND userid = :userid
                  ORDER BY starttime DESC";
            $params = array('lessonid' => $cisalesson->id, 'userid' => $user->id);

            if ($attempts = $DB->get_records_sql($sql, $params, 0, 1)) {
                $attempt = reset($attempts);
                if ($attempt->completed) {
                    $return->info = get_string("completed", "cisalesson");
                } else {
                    $return->info = get_string("notyetcompleted", "cisalesson");
                }
                $return->time = $attempt->lessontime;
            } else {
                $return->info = get_string("nolessonattempts", "cisalesson");
            }
        } else {
            if (!$grade->hidden || has_capability('moodle/grade:viewhidden', context_course::instance($course->id))) {
                $return->info = get_string('grade') . ': ' . $grade->str_long_grade;
            } else {
                $return->info = get_string('grade') . ': ' . get_string('hidden', 'grades');
            }

            $return->time = grade_get_date_for_user_grade($grade, $user);
        }
    }
    return $return;
}

/**
 * Print a detailed representation of what a  user has done with
 * a given particular instance of this module, for user activity reports.
 *
 * @global object
 * @param object $course
 * @param object $user
 * @param object $mod
 * @param object $cisalesson
 * @return bool
 */
function cisalesson_user_complete($course, $user, $mod, $cisalesson) {
    global $DB, $OUTPUT, $CFG;

    require_once("$CFG->libdir/gradelib.php");

    $grades = grade_get_grades($course->id, 'mod', 'cisalesson', $cisalesson->id, $user->id);

    // Display the grade and feedback.
    if (empty($grades->items[0]->grades)) {
        echo $OUTPUT->container(get_string("nolessonattempts", "cisalesson"));
    } else {
        $grade = reset($grades->items[0]->grades);
        if (empty($grade->grade)) {
            // Check to see if it an ungraded / incomplete attempt.
            $sql = "SELECT *
                      FROM {cisalesson_timer}
                     WHERE lessonid = :lessonid
                       AND userid = :userid
                     ORDER by starttime desc";
            $params = array('lessonid' => $cisalesson->id, 'userid' => $user->id);

            if ($attempt = $DB->get_record_sql($sql, $params, IGNORE_MULTIPLE)) {
                if ($attempt->completed) {
                    $status = get_string("completed", "cisalesson");
                } else {
                    $status = get_string("notyetcompleted", "cisalesson");
                }
            } else {
                $status = get_string("nolessonattempts", "cisalesson");
            }
        } else {
            if (!$grade->hidden || has_capability('moodle/grade:viewhidden', context_course::instance($course->id))) {
                $status = get_string("grade") . ': ' . $grade->str_long_grade;
            } else {
                $status = get_string('grade') . ': ' . get_string('hidden', 'grades');
            }
        }

        // Display the grade or lesson status if there isn't one.
        echo $OUTPUT->container($status);

        if ($grade->str_feedback &&
            (!$grade->hidden || has_capability('moodle/grade:viewhidden', context_course::instance($course->id)))) {
            echo $OUTPUT->container(get_string('feedback').': '.$grade->str_feedback);
        }
    }

    // Display the lesson progress.
    // Attempt, pages viewed, questions answered, correct answers, time.
    $params = array ("lessonid" => $cisalesson->id, "userid" => $user->id);
    $attempts = $DB->get_records_select("cisalesson_attempts", "lessonid = :lessonid AND userid = :userid", $params, "retry, timeseen");
    $branches = $DB->get_records_select("cisalesson_branch", "lessonid = :lessonid AND userid = :userid", $params, "retry, timeseen");
    $cybers = $DB->get_records_select("cisalesson_cyber", "lessonid = :lessonid AND userid = :userid", $params, "retry, timeseen");
    if (!empty($attempts) or !empty($branches) or !empty($cybers)) {
        echo $OUTPUT->box_start();
        $table = new html_table();
        // Table Headings.
        $table->head = array (get_string("attemptheader", "cisalesson"),
            get_string("totalpagesviewedheader", "cisalesson"),
            get_string("numberofpagesviewedheader", "cisalesson"),
            get_string("numberofcorrectanswersheader", "cisalesson"),
            get_string("time"));
        $table->width = "100%";
        $table->align = array ("center", "center", "center", "center", "center");
        $table->size = array ("*", "*", "*", "*", "*");
        $table->cellpadding = 2;
        $table->cellspacing = 0;

        $retry = 0;
        $nquestions = 0;
        $npages = 0;
        $ncorrect = 0;

        // Filter question pages (from lesson_attempts).
        foreach ($attempts as $attempt) {
            if ($attempt->retry == $retry) {
                $npages++;
                $nquestions++;
                if ($attempt->correct) {
                    $ncorrect++;
                }
                $timeseen = $attempt->timeseen;
            } else {
                $table->data[] = array($retry + 1, $npages, $nquestions, $ncorrect, userdate($timeseen));
                $retry++;
                $nquestions = 1;
                $npages = 1;
                if ($attempt->correct) {
                    $ncorrect = 1;
                } else {
                    $ncorrect = 0;
                }
            }
        }

        // Filter content pages (from lesson_branch).
        foreach ($branches as $branch) {
            if ($branch->retry == $retry) {
                $npages++;

                $timeseen = $branch->timeseen;
            } else {
                $table->data[] = array($retry + 1, $npages, $nquestions, $ncorrect, userdate($timeseen));
                $retry++;
                $npages = 1;
            }
        }
        // Filter cyber range dashboards (from lesson_cyber).
        foreach ($cybers as $cyber) {
            if ($cyber->retry == $retry) {
                $npages++;

                $timeseen = $cyber->timeseen;
            } else {
                $table->data[] = array($retry + 1, $npages, $nquestions, $ncorrect, userdate($timeseen));
                $retry++;
                $npages = 1;
            }
        }
        if ($npages > 0) {
                $table->data[] = array($retry + 1, $npages, $nquestions, $ncorrect, userdate($timeseen));
        }
        echo html_writer::table($table);
        echo $OUTPUT->box_end();
    }

    return true;
}

/**
 * @deprecated since Moodle 3.3, when the block_course_overview block was removed.
 */
function cisalesson_print_overview() {
    throw new coding_exception('cisalesson_print_overview() can not be used any more and is obsolete.');
}

/**
 * Function to be run periodically according to the moodle cron
 * This function searches for things that need to be done, such
 * as sending out mail, toggling flags etc ...
 * @global stdClass
 * @return bool true
 */
function cisalesson_cron () {
    global $CFG;

    return true;
}

/**
 * Return grade for given user or all users.
 *
 * @global stdClass
 * @global object
 * @param int $cisalessonid id of lesson
 * @param int $userid optional user id, 0 means all users
 * @return array array of grades, false if none
 */
function cisalesson_get_user_grades($cisalesson, $userid=0) {
    global $CFG, $DB;

    $params = array("lessonid" => $cisalesson->id,"lessonid2" => $cisalesson->id);

    if (!empty($userid)) {
        $params["userid"] = $userid;
        $params["userid2"] = $userid;
        $user = "AND u.id = :userid";
        $fuser = "AND uu.id = :userid2";
    }
    else {
        $user="";
        $fuser="";
    }

    if ($cisalesson->retake) {
        if ($cisalesson->usemaxgrade) {
            $sql = "SELECT u.id, u.id AS userid, MAX(g.grade) AS rawgrade
                      FROM {user} u, {cisalesson_grades} g
                     WHERE u.id = g.userid AND g.lessonid = :lessonid
                           $user
                  GROUP BY u.id";
        } else {
            $sql = "SELECT u.id, u.id AS userid, AVG(g.grade) AS rawgrade
                      FROM {user} u, {cisalesson_grades} g
                     WHERE u.id = g.userid AND g.lessonid = :lessonid
                           $user
                  GROUP BY u.id";
        }
        unset($params['lessonid2']);
        unset($params['userid2']);
    } else {
        // use only first attempts (with lowest id in lesson_grades table)
        $firstonly = "SELECT uu.id AS userid, MIN(gg.id) AS firstcompleted
                        FROM {user} uu, {cisalesson_grades} gg
                       WHERE uu.id = gg.userid AND gg.lessonid = :lessonid2
                             $fuser
                       GROUP BY uu.id";

        $sql = "SELECT u.id, u.id AS userid, g.grade AS rawgrade
                  FROM {user} u, {cisalesson_grades} g, ($firstonly) f
                 WHERE u.id = g.userid AND g.lessonid = :lessonid
                       AND g.id = f.firstcompleted AND g.userid=f.userid
                       $user";
    }

    return $DB->get_records_sql($sql, $params);
}

/**
 * Update grades in central gradebook
 *
 * @category grade
 * @param object $cisalesson
 * @param int $userid specific user only, 0 means all
 * @param bool $nullifnone
 */
function cisalesson_update_grades($cisalesson, $userid=0, $nullifnone=true) {
    global $CFG, $DB;
    require_once($CFG->libdir.'/gradelib.php');

    if ($cisalesson->grade == 0 || $cisalesson->practice) {
        cisalesson_grade_item_update($cisalesson);

    } else if ($grades = cisalesson_get_user_grades($cisalesson, $userid)) {
        cisalesson_grade_item_update($cisalesson, $grades);

    } else if ($userid and $nullifnone) {
        $grade = new stdClass();
        $grade->userid   = $userid;
        $grade->rawgrade = null;
        cisalesson_grade_item_update($cisalesson, $grade);

    } else {
        cisalesson_grade_item_update($cisalesson);
    }
}

/**
 * Create grade item for given lesson
 *
 * @category grade
 * @uses GRADE_TYPE_VALUE
 * @uses GRADE_TYPE_NONE
 * @param object $cisalesson object with extra cmidnumber
 * @param array|object $grades optional array/object of grade(s); 'reset' means reset grades in gradebook
 * @return int 0 if ok, error code otherwise
 */
function cisalesson_grade_item_update($cisalesson, $grades=null) {
    global $CFG;
    if (!function_exists('grade_update')) { //workaround for buggy PHP versions
        require_once($CFG->libdir.'/gradelib.php');
    }

    if (property_exists($cisalesson, 'cmidnumber')) { //it may not be always present
        $params = array('itemname'=>$cisalesson->name, 'idnumber'=>$cisalesson->cmidnumber);
    } else {
        $params = array('itemname'=>$cisalesson->name);
    }

    if (!$cisalesson->practice and $cisalesson->grade > 0) {
        $params['gradetype']  = GRADE_TYPE_VALUE;
        $params['grademax']   = $cisalesson->grade;
        $params['grademin']   = 0;
    } else if (!$cisalesson->practice and $cisalesson->grade < 0) {
        $params['gradetype']  = GRADE_TYPE_SCALE;
        $params['scaleid']   = -$cisalesson->grade;

        // Make sure current grade fetched correctly from $grades
        $currentgrade = null;
        if (!empty($grades)) {
            if (is_array($grades)) {
                $currentgrade = reset($grades);
            } else {
                $currentgrade = $grades;
            }
        }

        // When converting a score to a scale, use scale's grade maximum to calculate it.
        if (!empty($currentgrade) && $currentgrade->rawgrade !== null) {
            $grade = grade_get_grades($cisalesson->course, 'mod', 'cisalesson', $cisalesson->id, $currentgrade->userid);
            $params['grademax']   = reset($grade->items)->grademax;
        }
    } else {
        $params['gradetype']  = GRADE_TYPE_NONE;
    }

    if ($grades  === 'reset') {
        $params['reset'] = true;
        $grades = null;
    } else if (!empty($grades)) {
        // Need to calculate raw grade (Note: $grades has many forms)
        if (is_object($grades)) {
            $grades = array($grades->userid => $grades);
        } else if (array_key_exists('userid', $grades)) {
            $grades = array($grades['userid'] => $grades);
        }
        foreach ($grades as $key => $grade) {
            if (!is_array($grade)) {
                $grades[$key] = $grade = (array) $grade;
            }
            //check raw grade isnt null otherwise we erroneously insert a grade of 0
            if ($grade['rawgrade'] !== null) {
                $grades[$key]['rawgrade'] = ($grade['rawgrade'] * $params['grademax'] / 100);
            } else {
                //setting rawgrade to null just in case user is deleting a grade
                $grades[$key]['rawgrade'] = null;
            }
        }
    }

    return grade_update('mod/cisalesson', $cisalesson->course, 'mod', 'cisalesson', $cisalesson->id, 0, $grades, $params);
}

/**
 * List the actions that correspond to a view of this module.
 * This is used by the participation report.
 *
 * Note: This is not used by new logging system. Event with
 *       crud = 'r' and edulevel = LEVEL_PARTICIPATING will
 *       be considered as view action.
 *
 * @return array
 */
function cisalesson_get_view_actions() {
    return array('view','view all');
}

/**
 * List the actions that correspond to a post of this module.
 * This is used by the participation report.
 *
 * Note: This is not used by new logging system. Event with
 *       crud = ('c' || 'u' || 'd') and edulevel = LEVEL_PARTICIPATING
 *       will be considered as post action.
 *
 * @return array
 */
function cisalesson_get_post_actions() {
    return array('end','start');
}

/**
 * Runs any processes that must run before
 * a lesson insert/update
 *
 * @global object
 * @param object $cisalesson Lesson form data
 * @return void
 **/
function cisalesson_process_pre_save(&$cisalesson) {
    global $DB;

    $cisalesson->timemodified = time();

    if (empty($cisalesson->timelimit)) {
        $cisalesson->timelimit = 0;
    }
    if (empty($cisalesson->timespent) or !is_numeric($cisalesson->timespent) or $cisalesson->timespent < 0) {
        $cisalesson->timespent = 0;
    }
    if (!isset($cisalesson->completed)) {
        $cisalesson->completed = 0;
    }
    if (empty($cisalesson->gradebetterthan) or !is_numeric($cisalesson->gradebetterthan) or $cisalesson->gradebetterthan < 0) {
        $cisalesson->gradebetterthan = 0;
    } else if ($cisalesson->gradebetterthan > 100) {
        $cisalesson->gradebetterthan = 100;
    }

    if (empty($cisalesson->width)) {
        $cisalesson->width = 640;
    }
    if (empty($cisalesson->height)) {
        $cisalesson->height = 480;
    }
    if (empty($cisalesson->bgcolor)) {
        $cisalesson->bgcolor = '#FFFFFF';
    }

    // Conditions for dependency
    $conditions = new stdClass;
    $conditions->timespent = $cisalesson->timespent;
    $conditions->completed = $cisalesson->completed;
    $conditions->gradebetterthan = $cisalesson->gradebetterthan;
    $cisalesson->conditions = serialize($conditions);
    unset($cisalesson->timespent);
    unset($cisalesson->completed);
    unset($cisalesson->gradebetterthan);

    if (empty($cisalesson->password)) {
        unset($cisalesson->password);
    }
}

/**
 * Runs any processes that must be run
 * after a lesson insert/update
 *
 * @global object
 * @param object $cisalesson Lesson form data
 * @return void
 **/
function cisalesson_process_post_save(&$cisalesson) {
    // Update the events relating to this lesson.
    cisalesson_update_events($cisalesson);
    $completionexpected = (!empty($cisalesson->completionexpected)) ? $cisalesson->completionexpected : null;
    \core_completion\api::update_completion_date_event($cisalesson->coursemodule, 'cisalesson', $cisalesson, $completionexpected);
}


/**
 * Implementation of the function for printing the form elements that control
 * whether the course reset functionality affects the lesson.
 *
 * @param $mform form passed by reference
 */
function cisalesson_reset_course_form_definition(&$mform) {
    $mform->addElement('header', 'lessonheader', get_string('modulenameplural', 'cisalesson'));
    $mform->addElement('advcheckbox', 'reset_lesson', get_string('deleteallattempts','cisalesson'));
    $mform->addElement('advcheckbox', 'reset_lesson_user_overrides',
            get_string('removealluseroverrides', 'cisalesson'));
    $mform->addElement('advcheckbox', 'reset_lesson_group_overrides',
            get_string('removeallgroupoverrides', 'cisalesson'));
}

/**
 * Course reset form defaults.
 * @param object $course
 * @return array
 */
function cisalesson_reset_course_form_defaults($course) {
    return array('reset_lesson' => 1,
            'reset_lesson_group_overrides' => 1,
            'reset_lesson_user_overrides' => 1);
}

/**
 * Removes all grades from gradebook
 *
 * @global stdClass
 * @global object
 * @param int $courseid
 * @param string optional type
 */
function cisalesson_reset_gradebook($courseid, $type='') {
    global $CFG, $DB;

    $sql = "SELECT l.*, cm.idnumber as cmidnumber, l.course as courseid
              FROM {cisalesson} l, {course_modules} cm, {modules} m
             WHERE m.name='cisalesson' AND m.id=cm.module AND cm.instance=l.id AND l.course=:course";
    $params = array ("course" => $courseid);
    if ($cisalessons = $DB->get_records_sql($sql,$params)) {
        foreach ($cisalessons as $cisalesson) {
            cisalesson_grade_item_update($cisalesson, 'reset');
        }
    }
}

/**
 * Actual implementation of the reset course functionality, delete all the
 * lesson attempts for course $data->courseid.
 *
 * @global stdClass
 * @global object
 * @param object $data the data submitted from the reset course.
 * @return array status array
 */
function cisalesson_reset_userdata($data) {
    global $CFG, $DB;

    $componentstr = get_string('modulenameplural', 'cisalesson');
    $status = array();

    if (!empty($data->reset_lesson)) {
        $cisalessonssql = "SELECT l.id
                         FROM {cisalesson} l
                        WHERE l.course=:course";

        $params = array ("course" => $data->courseid);
        $cisalessons = $DB->get_records_sql($cisalessonssql, $params);

        // Get rid of attempts files.
        $fs = get_file_storage();
        if ($cisalessons) {
            foreach ($cisalessons as $cisalessonid => $unused) {
                if (!$cm = get_coursemodule_from_instance('cisalesson', $cisalessonid)) {
                    continue;
                }
                $context = context_module::instance($cm->id);
                $fs->delete_area_files($context->id, 'mod_cisalesson', 'essay_responses');
                $fs->delete_area_files($context->id, 'mod_cisalesson', 'essay_answers');
            }
        }

        $DB->delete_records_select('cisalesson_timer', "lessonid IN ($cisalessonssql)", $params);
        $DB->delete_records_select('cisalesson_grades', "lessonid IN ($cisalessonssql)", $params);
        $DB->delete_records_select('cisalesson_attempts', "lessonid IN ($cisalessonssql)", $params);
        $DB->delete_records_select('cisalesson_branch', "lessonid IN ($cisalessonssql)", $params);
        $DB->delete_records_select('cisalesson_cyber', "lessonid IN ($cisalessonssql)", $params);

        // remove all grades from gradebook
        if (empty($data->reset_gradebook_grades)) {
            cisalesson_reset_gradebook($data->courseid);
        }

        $status[] = array('component'=>$componentstr, 'item'=>get_string('deleteallattempts', 'cisalesson'), 'error'=>false);
    }

    // Remove user overrides.
    if (!empty($data->reset_lesson_user_overrides)) {
        $DB->delete_records_select('cisalesson_overrides',
                'lessonid IN (SELECT id FROM {cisalesson} WHERE course = ?) AND userid IS NOT NULL', array($data->courseid));
        $status[] = array(
        'component' => $componentstr,
        'item' => get_string('useroverridesdeleted', 'cisalesson'),
        'error' => false);
    }
    // Remove group overrides.
    if (!empty($data->reset_lesson_group_overrides)) {
        $DB->delete_records_select('cisalesson_overrides',
        'lessonid IN (SELECT id FROM {cisalesson} WHERE course = ?) AND groupid IS NOT NULL', array($data->courseid));
        $status[] = array(
        'component' => $componentstr,
        'item' => get_string('groupoverridesdeleted', 'cisalesson'),
        'error' => false);
    }
    /// updating dates - shift may be negative too
    if ($data->timeshift) {
        $DB->execute("UPDATE {cisalesson_overrides}
                         SET available = available + ?
                       WHERE lessonid IN (SELECT id FROM {cisalesson} WHERE course = ?)
                         AND available <> 0", array($data->timeshift, $data->courseid));
        $DB->execute("UPDATE {cisalesson_overrides}
                         SET deadline = deadline + ?
                       WHERE lessonid IN (SELECT id FROM {cisalesson} WHERE course = ?)
                         AND deadline <> 0", array($data->timeshift, $data->courseid));

        // Any changes to the list of dates that needs to be rolled should be same during course restore and course reset.
        // See MDL-9367.
        shift_course_mod_dates('cisalesson', array('available', 'deadline'), $data->timeshift, $data->courseid);
        $status[] = array('component'=>$componentstr, 'item'=>get_string('datechanged'), 'error'=>false);
    }

    return $status;
}

/**
 * @uses FEATURE_GROUPS
 * @uses FEATURE_GROUPINGS
 * @uses FEATURE_MOD_INTRO
 * @uses FEATURE_COMPLETION_TRACKS_VIEWS
 * @uses FEATURE_GRADE_HAS_GRADE
 * @uses FEATURE_GRADE_OUTCOMES
 * @param string $feature FEATURE_xx constant for requested feature
 * @return mixed True if module supports feature, false if not, null if doesn't know
*/
function cisalesson_supports($feature) {
    switch($feature) {
        case FEATURE_GROUPS:
            return true;
        case FEATURE_GROUPINGS:
            return true;
        case FEATURE_MOD_INTRO:
            return true;
        case FEATURE_COMPLETION_TRACKS_VIEWS:
            return true;
        case FEATURE_GRADE_HAS_GRADE:
            return true;
        case FEATURE_COMPLETION_HAS_RULES:
            return true;
        case FEATURE_GRADE_OUTCOMES:
            return true;
        case FEATURE_BACKUP_MOODLE2:
            return true;
        case FEATURE_SHOW_DESCRIPTION:
            return true;
        default:
            return null;
    }
}

/**
 * Obtains the automatic completion state for this lesson based on any conditions
 * in lesson settings.
 *
 * @param object $course Course
 * @param object $cm course-module
 * @param int $userid User ID
 * @param bool $type Type of comparison (or/and; can be used as return value if no conditions)
 * @return bool True if completed, false if not, $type if conditions not set.
 */
function cisalesson_get_completion_state($course, $cm, $userid, $type) {
    global $CFG, $DB;

    // Get lesson details.
    $cisalesson = $DB->get_record('cisalesson', array('id' => $cm->instance), '*',
            MUST_EXIST);

    $result = $type; // Default return value.
    // If completion option is enabled, evaluate it and return true/false.
    if ($cisalesson->completionendreached) {
        $value = $DB->record_exists('cisalesson_timer', array(
                'lessonid' => $cisalesson->id, 'userid' => $userid, 'completed' => 1));
        if ($type == COMPLETION_AND) {
            $result = $result && $value;
        } else {
            $result = $result || $value;
        }
    }
    if ($cisalesson->completiontimespent != 0) {
        $duration = $DB->get_field_sql(
                        "SELECT SUM(lessontime - starttime)
                               FROM {cisalesson_timer}
                              WHERE lessonid = :lessonid
                                AND userid = :userid",
                        array('userid' => $userid, 'lessonid' => $cisalesson->id));
        if (!$duration) {
            $duration = 0;
        }
        if ($type == COMPLETION_AND) {
            $result = $result && ($cisalesson->completiontimespent < $duration);
        } else {
            $result = $result || ($cisalesson->completiontimespent < $duration);
        }
    }
    return $result;
}
/**
 * This function extends the settings navigation block for the site.
 *
 * It is safe to rely on PAGE here as we will only ever be within the module
 * context when this is called
 *
 * @param settings_navigation $settings
 * @param navigation_node $cisalessonnode
 */
function cisalesson_extend_settings_navigation($settings, $cisalessonnode) {
    global $PAGE, $DB;

    // We want to add these new nodes after the Edit settings node, and before the
    // Locally assigned roles node. Of course, both of those are controlled by capabilities.
    $keys = $cisalessonnode->get_children_key_list();
    $beforekey = null;
    $i = array_search('modedit', $keys);
    if ($i === false and array_key_exists(0, $keys)) {
        $beforekey = $keys[0];
    } else if (array_key_exists($i + 1, $keys)) {
        $beforekey = $keys[$i + 1];
    }

    if (has_capability('mod/cisalesson:manageoverrides', $PAGE->cm->context)) {
        $url = new moodle_url('/mod/cisalesson/overrides.php', array('cmid' => $PAGE->cm->id));
        $node = navigation_node::create(get_string('groupoverrides', 'cisalesson'),
                new moodle_url($url, array('mode' => 'group')),
                navigation_node::TYPE_SETTING, null, 'mod_cisalesson_groupoverrides');
        $cisalessonnode->add_node($node, $beforekey);

        $node = navigation_node::create(get_string('useroverrides', 'cisalesson'),
                new moodle_url($url, array('mode' => 'user')),
                navigation_node::TYPE_SETTING, null, 'mod_cisalesson_useroverrides');
        $cisalessonnode->add_node($node, $beforekey);
    }

    if (has_capability('mod/cisalesson:edit', $PAGE->cm->context)) {
        $url = new moodle_url('/mod/cisalesson/view.php', array('id' => $PAGE->cm->id));
        $cisalessonnode->add(get_string('preview', 'cisalesson'), $url);
        $editnode = $cisalessonnode->add(get_string('edit', 'cisalesson'));
        $url = new moodle_url('/mod/cisalesson/edit.php', array('id' => $PAGE->cm->id, 'mode' => 'collapsed'));
        $editnode->add(get_string('collapsed', 'cisalesson'), $url);
        $url = new moodle_url('/mod/cisalesson/edit.php', array('id' => $PAGE->cm->id, 'mode' => 'full'));
        $editnode->add(get_string('full', 'cisalesson'), $url);
    }

    if (has_capability('mod/cisalesson:viewreports', $PAGE->cm->context)) {
        $reportsnode = $cisalessonnode->add(get_string('reports', 'cisalesson'));
        $url = new moodle_url('/mod/cisalesson/report.php', array('id'=>$PAGE->cm->id, 'action'=>'reportoverview'));
        $reportsnode->add(get_string('overview', 'cisalesson'), $url);
        $url = new moodle_url('/mod/cisalesson/report.php', array('id'=>$PAGE->cm->id, 'action'=>'reportdetail'));
        $reportsnode->add(get_string('detailedstats', 'cisalesson'), $url);
    }

    if (has_capability('mod/cisalesson:grade', $PAGE->cm->context)) {
        $url = new moodle_url('/mod/cisalesson/essay.php', array('id'=>$PAGE->cm->id));
        $cisalessonnode->add(get_string('manualgrading', 'cisalesson'), $url);
    }

}

/**
 * Get list of available import or export formats
 *
 * Copied and modified from lib/questionlib.php
 *
 * @param string $type 'import' if import list, otherwise export list assumed
 * @return array sorted list of import/export formats available
*/
function cisalesson_get_import_export_formats($type) {
    global $CFG;
    $fileformats = core_component::get_plugin_list("qformat");

    $fileformatname=array();
    foreach ($fileformats as $fileformat=>$fdir) {
        $format_file = "$fdir/format.php";
        if (file_exists($format_file) ) {
            require_once($format_file);
        } else {
            continue;
        }
        $classname = "qformat_$fileformat";
        $format_class = new $classname();
        if ($type=='import') {
            $provided = $format_class->provide_import();
        } else {
            $provided = $format_class->provide_export();
        }
        if ($provided) {
            $fileformatnames[$fileformat] = get_string('pluginname', 'qformat_'.$fileformat);
        }
    }
    natcasesort($fileformatnames);

    return $fileformatnames;
}

/**
 * Serves the lesson attachments. Implements needed access control ;-)
 *
 * @package mod_cisalesson
 * @category files
 * @param stdClass $course course object
 * @param stdClass $cm course module object
 * @param stdClass $context context object
 * @param string $filearea file area
 * @param array $args extra arguments
 * @param bool $forcedownload whether or not force download
 * @param array $options additional options affecting the file serving
 * @return bool false if file not found, does not return if found - justsend the file
 */
function cisalesson_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options=array()) {
    global $CFG, $DB;

    if ($context->contextlevel != CONTEXT_MODULE) {
        return false;
    }

    $fileareas = cisalesson_get_file_areas();
    if (!array_key_exists($filearea, $fileareas)) {
        return false;
    }

    if (!$cisalesson = $DB->get_record('cisalesson', array('id'=>$cm->instance))) {
        return false;
    }

    require_course_login($course, true, $cm);

    if ($filearea === 'page_contents') {
        $pageid = (int)array_shift($args);
        if (!$page = $DB->get_record('cisalesson_pages', array('id'=>$pageid))) {
            return false;
        }
        $fullpath = "/$context->id/mod_cisalesson/$filearea/$pageid/".implode('/', $args);

    } else if ($filearea === 'page_answers' || $filearea === 'page_responses') {
        $itemid = (int)array_shift($args);
        if (!$pageanswers = $DB->get_record('cisalesson_answers', array('id' => $itemid))) {
            return false;
        }
        $fullpath = "/$context->id/mod_cisalesson/$filearea/$itemid/".implode('/', $args);

    } else if ($filearea === 'essay_responses' || $filearea === 'essay_answers') {
        $itemid = (int)array_shift($args);
        if (!$attempt = $DB->get_record('cisalesson_attempts', array('id' => $itemid))) {
            return false;
        }
        $fullpath = "/$context->id/mod_cisalesson/$filearea/$itemid/".implode('/', $args);

    } else if ($filearea === 'mediafile') {
        if (count($args) > 1) {
            // Remove the itemid when it appears to be part of the arguments. If there is only one argument
            // then it is surely the file name. The itemid is sometimes used to prevent browser caching.
            array_shift($args);
        }
        $fullpath = "/$context->id/mod_cisalesson/$filearea/0/".implode('/', $args);

    } else {
        return false;
    }

    $fs = get_file_storage();
    if (!$file = $fs->get_file_by_hash(sha1($fullpath)) or $file->is_directory()) {
        return false;
    }

    // finally send the file
    send_stored_file($file, 0, 0, $forcedownload, $options); // download MUST be forced - security!
}

/**
 * Returns an array of file areas
 *
 * @package  mod_cisalesson
 * @category files
 * @return array a list of available file areas
 */
function cisalesson_get_file_areas() {
    $areas = array();
    $areas['page_contents'] = get_string('pagecontents', 'mod_cisalesson');
    $areas['mediafile'] = get_string('mediafile', 'mod_cisalesson');
    $areas['page_answers'] = get_string('pageanswers', 'mod_cisalesson');
    $areas['page_responses'] = get_string('pageresponses', 'mod_cisalesson');
    $areas['essay_responses'] = get_string('essayresponses', 'mod_cisalesson');
    $areas['essay_answers'] = get_string('essayresponses', 'mod_cisalesson');
    return $areas;
}

/**
 * Returns a file_info_stored object for the file being requested here
 *
 * @package  mod_cisalesson
 * @category files
 * @global stdClass $CFG
 * @param file_browse $browser file browser instance
 * @param array $areas file areas
 * @param stdClass $course course object
 * @param stdClass $cm course module object
 * @param stdClass $context context object
 * @param string $filearea file area
 * @param int $itemid item ID
 * @param string $filepath file path
 * @param string $filename file name
 * @return file_info_stored
 */
function cisalesson_get_file_info($browser, $areas, $course, $cm, $context, $filearea, $itemid, $filepath, $filename) {
    global $CFG, $DB;

    if (!has_capability('moodle/course:managefiles', $context)) {
        // No peeking here for students!
        return null;
    }

    // Mediafile area does not have sub directories, so let's select the default itemid to prevent
    // the user from selecting a directory to access the mediafile content.
    if ($filearea == 'mediafile' && is_null($itemid)) {
        $itemid = 0;
    }

    if (is_null($itemid)) {
        return new mod_cisalesson_file_info($browser, $course, $cm, $context, $areas, $filearea);
    }

    $fs = get_file_storage();
    $filepath = is_null($filepath) ? '/' : $filepath;
    $filename = is_null($filename) ? '.' : $filename;
    if (!$storedfile = $fs->get_file($context->id, 'mod_cisalesson', $filearea, $itemid, $filepath, $filename)) {
        return null;
    }

    $itemname = $filearea;
    if ($filearea == 'page_contents') {
        $itemname = $DB->get_field('cisalesson_pages', 'title', array('lessonid' => $cm->instance, 'id' => $itemid));
        $itemname = format_string($itemname, true, array('context' => $context));
    } else {
        $areas = cisalesson_get_file_areas();
        if (isset($areas[$filearea])) {
            $itemname = $areas[$filearea];
        }
    }

    $urlbase = $CFG->wwwroot . '/pluginfile.php';
    return new file_info_stored($browser, $context, $storedfile, $urlbase, $itemname, $itemid, true, true, false);
}


/**
 * Return a list of page types
 * @param string $pagetype current page type
 * @param stdClass $parentcontext Block's parent context
 * @param stdClass $currentcontext Current context of block
 */
function cisalesson_page_type_list($pagetype, $parentcontext, $currentcontext) {
    $module_pagetype = array(
        'mod-lesson-*'=>get_string('page-mod-lesson-x', 'cisalesson'),
        'mod-lesson-view'=>get_string('page-mod-lesson-view', 'cisalesson'),
        'mod-lesson-edit'=>get_string('page-mod-lesson-edit', 'cisalesson'));
    return $module_pagetype;
}

/**
 * Update the lesson activity to include any file
 * that was uploaded, or if there is none, set the
 * mediafile field to blank.
 *
 * @param int $cisalessonid the lesson id
 * @param stdClass $context the context
 * @param int $draftitemid the draft item
 */
function cisalesson_update_media_file($cisalessonid, $context, $draftitemid) {
    global $DB;

    // Set the filestorage object.
    $fs = get_file_storage();
    // Save the file if it exists that is currently in the draft area.
    file_save_draft_area_files($draftitemid, $context->id, 'mod_cisalesson', 'mediafile', 0);
    // Get the file if it exists.
    $files = $fs->get_area_files($context->id, 'mod_cisalesson', 'mediafile', 0, 'itemid, filepath, filename', false);
    // Check that there is a file to process.
    if (count($files) == 1) {
        // Get the first (and only) file.
        $file = reset($files);
        // Set the mediafile column in the lessons table.
        $DB->set_field('cisalesson', 'mediafile', '/' . $file->get_filename(), array('id' => $cisalessonid));
    } else {
        // Set the mediafile column in the lessons table.
        $DB->set_field('cisalesson', 'mediafile', '', array('id' => $cisalessonid));
    }
}

/**
 * Get icon mapping for font-awesome.
 */
function mod_cisalesson_get_fontawesome_icon_map() {
    return [
        'mod_cisalesson:e/copy' => 'fa-clone',
        'mod_cisalesson:e/flask' => 'fa-flask',
        'mod_cisalesson:e/server' => 'fa-server',
        'mod_cisalesson:e/desktop' => 'fa-desktop'
    ];
}

/*
 * Check if the module has any update that affects the current user since a given time.
 *
 * @param  cm_info $cm course module data
 * @param  int $from the time to check updates from
 * @param  array $filter  if we need to check only specific updates
 * @return stdClass an object with the different type of areas indicating if they were updated or not
 * @since Moodle 3.3
 */
function cisalesson_check_updates_since(cm_info $cm, $from, $filter = array()) {
    global $DB, $USER;

    $updates = course_check_module_updates_since($cm, $from, array(), $filter);

    // Check if there are new pages or answers in the lesson.
    $updates->pages = (object) array('updated' => false);
    $updates->answers = (object) array('updated' => false);
    $select = 'lessonid = ? AND (timecreated > ? OR timemodified > ?)';
    $params = array($cm->instance, $from, $from);

    $pages = $DB->get_records_select('cisalesson_pages', $select, $params, '', 'id');
    if (!empty($pages)) {
        $updates->pages->updated = true;
        $updates->pages->itemids = array_keys($pages);
    }
    $answers = $DB->get_records_select('cisalesson_answers', $select, $params, '', 'id');
    if (!empty($answers)) {
        $updates->answers->updated = true;
        $updates->answers->itemids = array_keys($answers);
    }

    // Check for new question attempts, grades, pages viewed and timers.
    $updates->questionattempts = (object) array('updated' => false);
    $updates->grades = (object) array('updated' => false);
    $updates->pagesviewed = (object) array('updated' => false);
    $updates->timers = (object) array('updated' => false);

    $select = 'lessonid = ? AND userid = ? AND timeseen > ?';
    $params = array($cm->instance, $USER->id, $from);

    $questionattempts = $DB->get_records_select('cisalesson_attempts', $select, $params, '', 'id');
    if (!empty($questionattempts)) {
        $updates->questionattempts->updated = true;
        $updates->questionattempts->itemids = array_keys($questionattempts);
    }
    $pagesviewed = $DB->get_records_select('cisalesson_branch', $select, $params, '', 'id');
    if (!empty($pagesviewed)) {
        $updates->pagesviewed->updated = true;
        $updates->pagesviewed->itemids = array_keys($pagesviewed);
    } else { // adding cyber range dashboard here, counts as pages viewed
        $pagesviewed = $DB->get_records_select('cisalesson_cyber', $select, $params, '', 'id');
        if (!empty($pagesviewed)) {
            $updates->userpagesviewed->updated = true;
            $updates->userpagesviewed->itemids = array_keys($pagesviewed);
        }
    }


    $select = 'lessonid = ? AND userid = ? AND completed > ?';
    $grades = $DB->get_records_select('cisalesson_grades', $select, $params, '', 'id');
    if (!empty($grades)) {
        $updates->grades->updated = true;
        $updates->grades->itemids = array_keys($grades);
    }

    $select = 'lessonid = ? AND userid = ? AND (starttime > ? OR lessontime > ? OR timemodifiedoffline > ?)';
    $params = array($cm->instance, $USER->id, $from, $from, $from);
    $timers = $DB->get_records_select('cisalesson_timer', $select, $params, '', 'id');
    if (!empty($timers)) {
        $updates->timers->updated = true;
        $updates->timers->itemids = array_keys($timers);
    }

    // Now, teachers should see other students updates.
    if (has_capability('mod/cisalesson:viewreports', $cm->context)) {
        $select = 'lessonid = ? AND timeseen > ?';
        $params = array($cm->instance, $from);

        $insql = '';
        $inparams = [];
        if (groups_get_activity_groupmode($cm) == SEPARATEGROUPS) {
            $groupusers = array_keys(groups_get_activity_shared_group_members($cm));
            if (empty($groupusers)) {
                return $updates;
            }
            list($insql, $inparams) = $DB->get_in_or_equal($groupusers);
            $select .= ' AND userid ' . $insql;
            $params = array_merge($params, $inparams);
        }

        $updates->userquestionattempts = (object) array('updated' => false);
        $updates->usergrades = (object) array('updated' => false);
        $updates->userpagesviewed = (object) array('updated' => false);
        $updates->usertimers = (object) array('updated' => false);

        $questionattempts = $DB->get_records_select('cisalesson_attempts', $select, $params, '', 'id');
        if (!empty($questionattempts)) {
            $updates->userquestionattempts->updated = true;
            $updates->userquestionattempts->itemids = array_keys($questionattempts);
        }
        $pagesviewed = $DB->get_records_select('cisalesson_branch', $select, $params, '', 'id');
        if (!empty($pagesviewed)) {
            $updates->userpagesviewed->updated = true;
            $updates->userpagesviewed->itemids = array_keys($pagesviewed);
        } else { // adding cyber range dashboard here, counts as pages viewed
            $pagesviewed = $DB->get_records_select('cisalesson_cyber', $select, $params, '', 'id');
            if (!empty($pagesviewed)) {
                $updates->userpagesviewed->updated = true;
                $updates->userpagesviewed->itemids = array_keys($pagesviewed);
            }
        }

        $select = 'lessonid = ? AND completed > ?';
        if (!empty($insql)) {
            $select .= ' AND userid ' . $insql;
        }
        $grades = $DB->get_records_select('cisalesson_grades', $select, $params, '', 'id');
        if (!empty($grades)) {
            $updates->usergrades->updated = true;
            $updates->usergrades->itemids = array_keys($grades);
        }

        $select = 'lessonid = ? AND (starttime > ? OR lessontime > ? OR timemodifiedoffline > ?)';
        $params = array($cm->instance, $from, $from, $from);
        if (!empty($insql)) {
            $select .= ' AND userid ' . $insql;
            $params = array_merge($params, $inparams);
        }
        $timers = $DB->get_records_select('cisalesson_timer', $select, $params, '', 'id');
        if (!empty($timers)) {
            $updates->usertimers->updated = true;
            $updates->usertimers->itemids = array_keys($timers);
        }
    }
    return $updates;
}

/**
 * This function receives a calendar event and returns the action associated with it, or null if there is none.
 *
 * This is used by block_myoverview in order to display the event appropriately. If null is returned then the event
 * is not displayed on the block.
 *
 * @param calendar_event $event
 * @param \core_calendar\action_factory $factory
 * @param int $userid User id to use for all capability checks, etc. Set to 0 for current user (default).
 * @return \core_calendar\local\event\entities\action_interface|null
 */
function mod_cisalesson_core_calendar_provide_event_action(calendar_event $event,
                                                       \core_calendar\action_factory $factory,
                                                       int $userid = 0) {
    global $DB, $CFG, $USER;
    require_once($CFG->dirroot . '/mod/cisalesson/locallib.php');

    if (!$userid) {
        $userid = $USER->id;
    }

    $cm = get_fast_modinfo($event->courseid, $userid)->instances['cisalesson'][$event->instance];

    if (!$cm->uservisible) {
        // The module is not visible to the user for any reason.
        return null;
    }

    $completion = new \completion_info($cm->get_course());

    $completiondata = $completion->get_data($cm, false, $userid);

    if ($completiondata->completionstate != COMPLETION_INCOMPLETE) {
        return null;
    }

    $cisalesson = new cisalesson($DB->get_record('cisalesson', array('id' => $cm->instance), '*', MUST_EXIST));

    if ($cisalesson->count_user_retries($userid)) {
        // If the user has attempted the lesson then there is no further action for the user.
        return null;
    }

    // Apply overrides.
    $cisalesson->update_effective_access($userid);

    if (!$cisalesson->is_participant($userid)) {
        // If the user is not a participant then they have
        // no action to take. This will filter out the events for teachers.
        return null;
    }

    return $factory->create_instance(
        get_string('startlesson', 'cisalesson'),
        new \moodle_url('/mod/cisalesson/view.php', ['id' => $cm->id]),
        1,
        $cisalesson->is_accessible()
    );
}

/**
 * Add a get_coursemodule_info function in case any lesson type wants to add 'extra' information
 * for the course (see resource).
 *
 * Given a course_module object, this function returns any "extra" information that may be needed
 * when printing this activity in a course listing.  See get_array_of_activities() in course/lib.php.
 *
 * @param stdClass $coursemodule The coursemodule object (record).
 * @return cached_cm_info An object on information that the courses
 *                        will know about (most noticeably, an icon).
 */
function cisalesson_get_coursemodule_info($coursemodule) {
    global $DB;

    $dbparams = ['id' => $coursemodule->instance];
    $fields = 'id, name, intro, introformat, completionendreached, completiontimespent';
    if (!$cisalesson = $DB->get_record('cisalesson', $dbparams, $fields)) {
        return false;
    }

    $result = new cached_cm_info();
    $result->name = $cisalesson->name;

    if ($coursemodule->showdescription) {
        // Convert intro to html. Do not filter cached version, filters run at display time.
        $result->content = format_module_intro('cisalesson', $cisalesson, $coursemodule->id, false);
    }

    // Populate the custom completion rules as key => value pairs, but only if the completion mode is 'automatic'.
    if ($coursemodule->completion == COMPLETION_TRACKING_AUTOMATIC) {
        $result->customdata['customcompletionrules']['completionendreached'] = $cisalesson->completionendreached;
        $result->customdata['customcompletionrules']['completiontimespent'] = $cisalesson->completiontimespent;
    }

    return $result;
}

/**
 * Callback which returns human-readable strings describing the active completion custom rules for the module instance.
 *
 * @param cm_info|stdClass $cm object with fields ->completion and ->customdata['customcompletionrules']
 * @return array $descriptions the array of descriptions for the custom rules.
 */
function mod_cisalesson_get_completion_active_rule_descriptions($cm) {
    // Values will be present in cm_info, and we assume these are up to date.
    if (empty($cm->customdata['customcompletionrules'])
        || $cm->completion != COMPLETION_TRACKING_AUTOMATIC) {
        return [];
    }

    $descriptions = [];
    foreach ($cm->customdata['customcompletionrules'] as $key => $val) {
        switch ($key) {
            case 'completionendreached':
                if (!empty($val)) {
                    $descriptions[] = get_string('completionendreached_desc', 'cisalesson', $val);
                }
                break;
            case 'completiontimespent':
                if (!empty($val)) {
                    $descriptions[] = get_string('completiontimespentdesc', 'cisalesson', format_time($val));
                }
                break;
            default:
                break;
        }
    }
    return $descriptions;
}

/**
 * This function calculates the minimum and maximum cutoff values for the timestart of
 * the given event.
 *
 * It will return an array with two values, the first being the minimum cutoff value and
 * the second being the maximum cutoff value. Either or both values can be null, which
 * indicates there is no minimum or maximum, respectively.
 *
 * If a cutoff is required then the function must return an array containing the cutoff
 * timestamp and error string to display to the user if the cutoff value is violated.
 *
 * A minimum and maximum cutoff return value will look like:
 * [
 *     [1505704373, 'The due date must be after the start date'],
 *     [1506741172, 'The due date must be before the cutoff date']
 * ]
 *
 * @param calendar_event $event The calendar event to get the time range for
 * @param stdClass $instance The module instance to get the range from
 * @return array
 */
function mod_cisalesson_core_calendar_get_valid_event_timestart_range(\calendar_event $event, \stdClass $instance) {
    $mindate = null;
    $maxdate = null;

    if ($event->eventtype == CISALESSON_EVENT_TYPE_OPEN) {
        // The start time of the open event can't be equal to or after the
        // close time of the lesson activity.
        if (!empty($instance->deadline)) {
            $maxdate = [
                $instance->deadline,
                get_string('openafterclose', 'cisalesson')
            ];
        }
    } else if ($event->eventtype == CISALESSON_EVENT_TYPE_CLOSE) {
        // The start time of the close event can't be equal to or earlier than the
        // open time of the lesson activity.
        if (!empty($instance->available)) {
            $mindate = [
                $instance->available,
                get_string('closebeforeopen', 'cisalesson')
            ];
        }
    }

    return [$mindate, $maxdate];
}

/**
 * This function will update the lesson module according to the
 * event that has been modified.
 *
 * It will set the available or deadline value of the lesson instance
 * according to the type of event provided.
 *
 * @throws \moodle_exception
 * @param \calendar_event $event
 * @param stdClass $cisalesson The module instance to get the range from
 */
function mod_cisalesson_core_calendar_event_timestart_updated(\calendar_event $event, \stdClass $cisalesson) {
    global $DB;

    if (empty($event->instance) || $event->modulename != 'cisalesson') {
        return;
    }

    if ($event->instance != $cisalesson->id) {
        return;
    }

    if (!in_array($event->eventtype, [CISALESSON_EVENT_TYPE_OPEN, CISALESSON_EVENT_TYPE_CLOSE])) {
        return;
    }

    $courseid = $event->courseid;
    $modulename = $event->modulename;
    $instanceid = $event->instance;
    $modified = false;

    $coursemodule = get_fast_modinfo($courseid)->instances[$modulename][$instanceid];
    $context = context_module::instance($coursemodule->id);

    // The user does not have the capability to modify this activity.
    if (!has_capability('moodle/course:manageactivities', $context)) {
        return;
    }

    if ($event->eventtype == CISALESSON_EVENT_TYPE_OPEN) {
        // If the event is for the lesson activity opening then we should
        // set the start time of the lesson activity to be the new start
        // time of the event.
        if ($cisalesson->available != $event->timestart) {
            $cisalesson->available = $event->timestart;
            $cisalesson->timemodified = time();
            $modified = true;
        }
    } else if ($event->eventtype == CISALESSON_EVENT_TYPE_CLOSE) {
        // If the event is for the lesson activity closing then we should
        // set the end time of the lesson activity to be the new start
        // time of the event.
        if ($cisalesson->deadline != $event->timestart) {
            $cisalesson->deadline = $event->timestart;
            $modified = true;
        }
    }

    if ($modified) {
        $cisalesson->timemodified = time();
        $DB->update_record('cisalesson', $cisalesson);
        $event = \core\event\course_module_updated::create_from_cm($coursemodule, $context);
        $event->trigger();
    }
}
