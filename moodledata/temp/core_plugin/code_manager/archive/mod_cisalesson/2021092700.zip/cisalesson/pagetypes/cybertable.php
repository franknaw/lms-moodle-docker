<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Branch Table
 *
 * @package mod_cisalesson
 * based on mod_lesson, @copyright  2009 Sam Hemelryk
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 **/

defined('MOODLE_INTERNAL') || die();

 /** Branch Table page */
define("CISALESSON_PAGE_CYBERTABLE",   "25");

class cisalesson_page_type_cybertable extends cisalesson_page {

    protected $type = cisalesson_page::TYPE_STRUCTURE;
    protected $typeid = CISALESSON_PAGE_CYBERTABLE;
    protected $typeidstring = 'cybertable';
    protected $string = null;
    protected $jumpto = null;

    public function get_typeid() {
        return $this->typeid;
    }
    public function get_typestring() {
        if ($this->string===null) {
            $this->string = get_string($this->typeidstring, 'cisalesson');
        }
        return $this->string;
    }

    /**
     * Gets an array of the jumps used by the answers of this page
     *
     * @return array
     */
    public function get_jumps() {
        global $DB;
        $jumps = array();
        $params = array ("lessonid" => $this->cisalesson->id, "pageid" => $this->properties->id);
        if ($answers = $this->get_answers()) {
            foreach ($answers as $answer) {
                if ($answer->answer === '') {
                    // show only jumps for real branches (==have description)
                    continue;
                }
                $jumps[] = $this->get_jump_name($answer->jumpto);
            }
        } else {
            // We get here is the lesson was created on a Moodle 1.9 site and
            // the lesson contains question pages without any answers.
            $jumps[] = $this->get_jump_name($this->properties->nextpageid);
        }
        return $jumps;
    }

    public static function get_jumptooptions($firstpage, cisalesson $cisalesson) {
        global $DB, $PAGE;
        $jump = array();
        $jump[0] = get_string("thispage", "cisalesson");
        $jump[CISALESSON_NEXTPAGE] = get_string("nextpage", "cisalesson");
        $jump[CISALESSON_PREVIOUSPAGE] = get_string("previouspage", "cisalesson");
        $jump[CISALESSON_EOL] = get_string("endoflesson", "cisalesson");
        $jump[CISALESSON_UNSEENBRANCHPAGE] = get_string("unseenpageinbranch", "cisalesson");
        $jump[CISALESSON_RANDOMPAGE] = get_string("randompageinbranch", "cisalesson");
        $jump[CISALESSON_RANDOMBRANCH] = get_string("randombranch", "cisalesson");
        // Note - if we want to support jumping to random cyber range dashboards
        // we'll need to add variables duplicating the above later.
        if (!$firstpage) {
            if (!$apageid = $DB->get_field("cisalesson_pages", "id", array("lessonid" => $cisalesson->id, "prevpageid" => 0))) {
                print_error('cannotfindfirstpage', 'cisalesson');
            }
            while (true) {
                if ($apageid) {
                    $title = $DB->get_field("cisalesson_pages", "title", array("id" => $apageid));
                    $jump[$apageid] = $title;
                    $apageid = $DB->get_field("cisalesson_pages", "nextpageid", array("id" => $apageid));
                } else {
                    // last page reached
                    break;
                }
            }
         }
        return $jump;
    }
    public function get_idstring() {
        return $this->typeidstring;
    }
    public function display($renderer, $attempt) {
        global $PAGE, $CFG;

        $output = '';
        $options = new stdClass;
        $options->para = false;
        $options->noclean = true;

        if ($this->cisalesson->slideshow) {
            $output .= $renderer->slideshow_start($this->cisalesson);
        }
        // We are using level 3 header because the page title is a sub-heading of lesson title (MDL-30911).
        $output .= $renderer->heading(format_string($this->properties->title), 3);
        $output .= $renderer->box($this->get_cyber(), 'cyberdashboard');
        $output .= $renderer->box($this->get_contents(), 'contents cybercontents');

        $buttons = array();
        $i = 0;
        foreach ($this->get_answers() as $answer) {
            if ($answer->answer === '') {
                // not a branch!
                continue;
            }
            $params = array();
            $params['id'] = $PAGE->cm->id;
            $params['pageid'] = $this->properties->id;
            $params['sesskey'] = sesskey();
            $params['jumpto'] = $answer->jumpto;
            $url = new moodle_url('/mod/cisalesson/continue.php', $params);
            $buttons[] = $renderer->single_button($url, strip_tags(format_text($answer->answer, FORMAT_MOODLE, $options)));
            $i++;
        }
        // Set the orientation
        // Note - update the names below when we have css to support cyber range dashboards
        if ($this->properties->layout) {
            $buttonshtml = $renderer->box(implode("\n", $buttons), 'branchbuttoncontainer horizontal');
        } else {
            $buttonshtml = $renderer->box(implode("\n", $buttons), 'branchbuttoncontainer vertical');
        }
        $output .= $buttonshtml;

        if ($this->cisalesson->slideshow) {
            $output .= $renderer->slideshow_end();
        }

        // Trigger an event: content page viewed.
        $eventparams = array(
            'context' => context_module::instance($PAGE->cm->id),
            'objectid' => $this->properties->id
            );

        $event = \mod_cisalesson\event\cyber_dash_viewed::create($eventparams);
        $event->trigger();

        return $output;
    }

    public function check_answer() {
        global $USER, $DB, $PAGE, $CFG;

        $result = parent::check_answer();

        require_sesskey();
        $newpageid = optional_param('jumpto', null, PARAM_INT);
        // going to insert into lesson_branch
        if ($newpageid == CISALESSON_RANDOMBRANCH) {
            $cyberflag = 1;
        } else {
            $cyberflag = 0;
        }
        if ($grades = $DB->get_records("cisalesson_grades", array("lessonid" => $this->cisalesson->id, "userid" => $USER->id), "grade DESC")) {
            $retries = count($grades);
        } else {
            $retries = 0;
        }

        // First record this page in lesson_branch. This record may be needed by cisalesson_unseen_branch_jump.
        $cyber = new stdClass;
        $cyber->lessonid = $this->cisalesson->id;
        $cyber->userid = $USER->id;
        $cyber->pageid = $this->properties->id;
        $cyber->retry = $retries;
        $cyber->flag = $cyberflag;
        $cyber->timeseen = time();
        $cyber->nextpageid = 0;    // Next page id will be set later.
        $cyber->id = $DB->insert_record("cisalesson_cyber", $cyber);

        //  this is called when jumping to random from a branch table
        $context = context_module::instance($PAGE->cm->id);
        if($newpageid == CISALESSON_UNSEENBRANCHPAGE) {
            if (has_capability('mod/cisalesson:manage', $context)) {
                 $newpageid = CISALESSON_NEXTPAGE;
            } else {
                 $newpageid = cisalesson_unseen_question_jump($this->cisalesson, $USER->id, $this->properties->id);  // this may return 0
            }
        }
        // convert jumpto page into a proper page id
        if ($newpageid == 0) {
            $newpageid = $this->properties->id;
        } elseif ($newpageid == CISALESSON_NEXTPAGE) {
            if (!$newpageid = $this->nextpageid) {
                // no nextpage go to end of lesson
                $newpageid = CISALESSON_EOL;
            }
        } elseif ($newpageid == CISALESSON_PREVIOUSPAGE) {
            $newpageid = $this->prevpageid;
        } elseif ($newpageid == CISALESSON_RANDOMPAGE) {
            $newpageid = cisalesson_random_question_jump($this->cisalesson, $this->properties->id);
        } elseif ($newpageid == CISALESSON_RANDOMBRANCH) {
            $newpageid = cisalesson_unseen_branch_jump($this->cisalesson, $USER->id);
        }

        // Update record to set nextpageid.
        $cyber->nextpageid = $newpageid;
        $DB->update_record("cisalesson_cyber", $cyber);

        // This will force to redirect to the newpageid.
        $result->inmediatejump = true;
        $result->newpageid = $newpageid;
        return $result;
    }

    public function display_answers(html_table $table) {
        $answers = $this->get_answers();
        $options = new stdClass;
        $options->noclean = true;
        $options->para = false;
        $i = 1;
        foreach ($answers as $answer) {
            if ($answer->answer === '') {
                // not a branch!
                continue;
            }
            $cells = array();
            $cells[] = '<label>' . get_string('cyber', 'cisalesson') . ' ' . $i . '</label>: ';
            $cells[] = format_text($answer->answer, $answer->answerformat, $options);
            $table->data[] = new html_table_row($cells);

            $cells = array();
            $cells[] = '<label>' . get_string('jump', 'cisalesson') . ' ' . $i . '</label>: ';
            $cells[] = $this->get_jump_name($answer->jumpto);
            $table->data[] = new html_table_row($cells);

            if ($i === 1){
                $table->data[count($table->data)-1]->cells[0]->style = 'width:20%;';
            }
            $i++;
        }
        return $table;
    }
    public function get_grayout() {
        return 1;
    }
    public function report_answers($answerpage, $answerdata, $useranswer, $pagestats, &$i, &$n) {
        $answers = $this->get_answers();
        $formattextdefoptions = new stdClass;
        $formattextdefoptions->para = false;  //I'll use it widely in this page
        $formattextdefoptions->context = $answerpage->context;

        foreach ($answers as $answer) {
            $data = "<input type=\"button\" class=\"btn btn-secondary\" name=\"$answer->id\" " .
                    "value=\"".s(strip_tags(format_text($answer->answer, FORMAT_MOODLE, $formattextdefoptions)))."\" " .
                    "disabled=\"disabled\"> ";
            $data .= get_string('jumpsto', 'cisalesson', $this->get_jump_name($answer->jumpto));
            $answerdata->answers[] = array($data, "");
            $answerpage->answerdata = $answerdata;
        }
        return $answerpage;
    }

    public function update($properties, $context = null, $maxbytes = null) {
        if (empty($properties->display)) {
            $properties->display = '0';
        }
        if (empty($properties->layout)) {
            $properties->layout = '0';
        }
        return parent::update($properties);
    }
    public function add_page_link($previd) {
        global $PAGE, $CFG;
        $addurl = new moodle_url('/mod/cisalesson/editpage.php', array('id'=>$PAGE->cm->id, 'pageid'=>$previd, 'qtype'=>CISALESSON_PAGE_CYBERTABLE));
        return array('addurl'=>$addurl, 'type'=>CISALESSON_PAGE_CYBERTABLE, 'name'=>get_string('addacybertable', 'cisalesson'));
    }
    protected function get_displayinmenublock() {
        return true;
    }
    public function is_unseen($param) {
        global $USER, $DB;
        if (is_array($param)) {
            $seenpages = $param;
            $branchpages = $this->cisalesson->get_sub_pages_of($this->properties->id, array(CISALESSON_PAGE_CYBERTABLE, CISALESSON_PAGE_ENDOFBRANCH));
            foreach ($branchpages as $branchpage) {
                if (array_key_exists($branchpage->id, $seenpages)) {  // check if any of the pages have been viewed
                    return false;
                }
            }
            return true;
        } else {
            $nretakes = $param;
            if (!$DB->count_records("cisalesson_attempts", array("pageid"=>$this->properties->id, "userid"=>$USER->id, "retry"=>$nretakes))) {
                return true;
            }
            return false;
        }
    }
}

class cisalesson_add_page_form_cybertable extends cisalesson_add_page_form_base {

    public $qtype = CISALESSON_PAGE_CYBERTABLE;
    public $qtypestring = 'cybertable';
    protected $standard = false;

    public function custom_definition() {
        global $PAGE, $CFG;

        $mform = $this->_form;
        $cisalesson = $this->_customdata['cisalesson'];

        $firstpage = optional_param('firstpage', false, PARAM_BOOL);

        $jumptooptions = cisalesson_page_type_cybertable::get_jumptooptions($firstpage, $cisalesson);

        if ($this->_customdata['edit']) {
            $mform->setDefault('qtypeheading', get_string('editcybertable', 'cisalesson'));
        } else {
            $mform->setDefault('qtypeheading', get_string('addacybertable', 'cisalesson'));
        }

        $mform->addElement('hidden', 'firstpage');
        $mform->setType('firstpage', PARAM_BOOL);
        $mform->setDefault('firstpage', $firstpage);

        $mform->addElement('hidden', 'qtype');
        $mform->setType('qtype', PARAM_INT);

        $mform->addElement('text', 'title', get_string("pagetitle", "cisalesson"), array('size'=>70));
        $mform->addRule('title', null, 'required', null, 'server');
        if (!empty($CFG->formatstringstriptags)) {
            $mform->setType('title', PARAM_TEXT);
        } else {
            $mform->setType('title', PARAM_CLEANHTML);
        }

        $this->editoroptions = array('noclean'=>true, 'maxfiles'=>EDITOR_UNLIMITED_FILES, 'maxbytes'=>$PAGE->course->maxbytes);
        $mform->addElement('editor', 'contents_editor', get_string("pagecontents", "cisalesson"), null, $this->editoroptions);
        $mform->setType('contents_editor', PARAM_RAW);

        $mform->addElement('checkbox', 'layout', null, get_string("arrangebuttonshorizontally", "cisalesson"));
        $mform->setDefault('layout', true);

        $mform->addElement('checkbox', 'display', null, get_string("displayinleftmenu", "cisalesson"));
        $mform->setDefault('display', true);

        for ($i = 0; $i < $cisalesson->maxanswers; $i++) {
            $mform->addElement('header', 'headeranswer'.$i, get_string('branch', 'cisalesson').' '.($i+1));
            $this->add_answer($i, get_string("description", "cisalesson"), $i == 0);

            $mform->addElement('select', 'jumpto['.$i.']', get_string("jump", "cisalesson"), $jumptooptions);
            if ($i === 0) {
                $mform->setDefault('jumpto['.$i.']', 0);
            } else {
                $mform->setDefault('jumpto['.$i.']', CISALESSON_NEXTPAGE);
            }
        }
    }
}
