<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package mod_cisalesson
 * @subpackage backup-moodle2
 * @copyright 2010 onwards Eloy Lafuente (stronk7) {@link http://stronk7.com}
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

/**
 * Define all the restore steps that will be used by the restore_cisalesson_activity_task
 */

/**
 * Structure step to restore one lesson activity
 */
class restore_cisalesson_activity_structure_step extends restore_activity_structure_step {
    // Store the answers as they're received but only process them at the
    // end of the lesson
    protected $answers = array();

    protected function define_structure() {

        $paths = array();
        $userinfo = $this->get_setting_value('userinfo');

        $paths[] = new restore_path_element('cisalesson', '/activity/cisalesson');
        $paths[] = new restore_path_element('cisalesson_page', '/activity/cisalesson/pages/page');
        $paths[] = new restore_path_element('cisalesson_answer', '/activity/cisalesson/pages/page/answers/answer');
        $paths[] = new restore_path_element('cisalesson_override', '/activity/cisalesson/overrides/override');
        if ($userinfo) {
            $paths[] = new restore_path_element('cisalesson_attempt', '/activity/cisalesson/pages/page/answers/answer/attempts/attempt');
            $paths[] = new restore_path_element('cisalesson_grade', '/activity/cisalesson/grades/grade');
            $paths[] = new restore_path_element('cisalesson_branch', '/activity/cisalesson/pages/page/branches/branch');
            $paths[] = new restore_path_element('cisalesson_cyber', '/activity/cisalesson/pages/page/cybers/cyber');
            $paths[] = new restore_path_element('cisalesson_highscore', '/activity/cisalesson/highscores/highscore');
            $paths[] = new restore_path_element('cisalesson_timer', '/activity/cisalesson/timers/timer');
        }

        // Return the paths wrapped into standard activity structure
        return $this->prepare_activity_structure($paths);
    }

    protected function process_cisalesson($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->course = $this->get_courseid();

        // Any changes to the list of dates that needs to be rolled should be same during course restore and course reset.
        // See MDL-9367.
        $data->available = $this->apply_date_offset($data->available);
        $data->deadline = $this->apply_date_offset($data->deadline);

        // The lesson->highscore code was removed in MDL-49581.
        // Remove it if found in the backup file.
        if (isset($data->showhighscores)) {
            unset($data->showhighscores);
        }
        if (isset($data->highscores)) {
            unset($data->highscores);
        }

        // Supply items that maybe missing from previous versions.
        if (!isset($data->completionendreached)) {
            $data->completionendreached = 0;
        }
        if (!isset($data->completiontimespent)) {
            $data->completiontimespent = 0;
        }

        if (!isset($data->intro)) {
            $data->intro = '';
            $data->introformat = FORMAT_HTML;
        }

        // Compatibility with old backups with maxtime and timed fields.
        if (!isset($data->timelimit)) {
            if (isset($data->timed) && isset($data->maxtime) && $data->timed) {
                $data->timelimit = 60 * $data->maxtime;
            } else {
                $data->timelimit = 0;
            }
        }
        // insert the lesson record
        $newitemid = $DB->insert_record('cisalesson', $data);
        // immediately after inserting "activity" record, call this
        $this->apply_activity_instance($newitemid);
    }

    protected function process_cisalesson_page($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->lessonid = $this->get_new_parentid('cisalesson');

        // We'll remap all the prevpageid and nextpageid at the end, once all pages have been created

        $newitemid = $DB->insert_record('cisalesson_pages', $data);
        $this->set_mapping('cisalesson_page', $oldid, $newitemid, true); // Has related fileareas
    }

    protected function process_cisalesson_answer($data) {
        global $DB;

        $data = (object)$data;
        $data->lessonid = $this->get_new_parentid('cisalesson');
        $data->pageid = $this->get_new_parentid('cisalesson_page');
        $data->answer = $data->answer_text;

        // Set a dummy mapping to get the old ID so that it can be used by get_old_parentid when
        // processing attempts. It will be corrected in after_execute
        $this->set_mapping('cisalesson_answer', $data->id, 0, true); // Has related fileareas.

        // Answers need to be processed in order, so we store them in an
        // instance variable and insert them in the after_execute stage
        $this->answers[$data->id] = $data;
    }

    protected function process_cisalesson_attempt($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->lessonid = $this->get_new_parentid('cisalesson');
        $data->pageid = $this->get_new_parentid('cisalesson_page');

        // We use the old answerid here as the answer isn't created until after_execute
        $data->answerid = $this->get_old_parentid('cisalesson_answer');
        $data->userid = $this->get_mappingid('user', $data->userid);

        $newitemid = $DB->insert_record('cisalesson_attempts', $data);
        $this->set_mapping('cisalesson_attempt', $oldid, $newitemid, true); // Has related fileareas.
    }

    protected function process_cisalesson_grade($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->lessonid = $this->get_new_parentid('cisalesson');
        $data->userid = $this->get_mappingid('user', $data->userid);

        $newitemid = $DB->insert_record('cisalesson_grades', $data);
        $this->set_mapping('cisalesson_grade', $oldid, $newitemid);
    }

    protected function process_cisalesson_branch($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->lessonid = $this->get_new_parentid('cisalesson');
        $data->pageid = $this->get_new_parentid('cisalesson_page');
        $data->userid = $this->get_mappingid('user', $data->userid);

        $newitemid = $DB->insert_record('cisalesson_branch', $data);
    }

    protected function process_cisalesson_cyber($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->lessonid = $this->get_new_parentid('cisalesson');
        $data->pageid = $this->get_new_parentid('cisalesson_page');
        $data->userid = $this->get_mappingid('user', $data->userid);

        $newitemid = $DB->insert_record('cisalesson_cyber', $data);
    }

    protected function process_cisalesson_highscore($data) {
        // Do not process any high score data.
        // high scores were removed in Moodle 3.0 See MDL-49581.
    }

    protected function process_cisalesson_timer($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->lessonid = $this->get_new_parentid('cisalesson');
        $data->userid = $this->get_mappingid('user', $data->userid);
        // Supply item that maybe missing from previous versions.
        if (!isset($data->completed)) {
            $data->completed = 0;
        }
        $newitemid = $DB->insert_record('cisalesson_timer', $data);
    }

    /**
     * Process a lesson override restore
     * @param object $data The data in object form
     * @return void
     */
    protected function process_cisalesson_override($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        // Based on userinfo, we'll restore user overides or no.
        $userinfo = $this->get_setting_value('userinfo');

        // Skip user overrides if we are not restoring userinfo.
        if (!$userinfo && !is_null($data->userid)) {
            return;
        }

        $data->lessonid = $this->get_new_parentid('cisalesson');

        if (!is_null($data->userid)) {
            $data->userid = $this->get_mappingid('user', $data->userid);
        }
        if (!is_null($data->groupid)) {
            $data->groupid = $this->get_mappingid('group', $data->groupid);
        }

        // Skip if there is no user and no group data.
        if (empty($data->userid) && empty($data->groupid)) {
            return;
        }

        $data->available = $this->apply_date_offset($data->available);
        $data->deadline = $this->apply_date_offset($data->deadline);

        $newitemid = $DB->insert_record('cisalesson_overrides', $data);

        // Add mapping, restore of logs needs it.
        $this->set_mapping('cisalesson_override', $oldid, $newitemid);
    }

    protected function after_execute() {
        global $DB;

        // Answers must be sorted by id to ensure that they're shown correctly
        ksort($this->answers);
        foreach ($this->answers as $answer) {
            $newitemid = $DB->insert_record('cisalesson_answers', $answer);
            $this->set_mapping('cisalesson_answer', $answer->id, $newitemid, true);

            // Update the lesson attempts to use the newly created answerid
            $DB->set_field('cisalesson_attempts', 'answerid', $newitemid, array(
                    'lessonid' => $answer->lessonid,
                    'pageid' => $answer->pageid,
                    'answerid' => $answer->id));
        }

        // Add lesson files, no need to match by itemname (just internally handled context).
        $this->add_related_files('mod_cisalesson', 'intro', null);
        $this->add_related_files('mod_cisalesson', 'mediafile', null);
        // Add lesson page files, by lesson_page itemname
        $this->add_related_files('mod_cisalesson', 'page_contents', 'cisalesson_page');
        $this->add_related_files('mod_cisalesson', 'page_answers', 'cisalesson_answer');
        $this->add_related_files('mod_cisalesson', 'page_responses', 'cisalesson_answer');
        $this->add_related_files('mod_cisalesson', 'essay_responses', 'cisalesson_attempt');
        $this->add_related_files('mod_cisalesson', 'essay_answers', 'cisalesson_attempt');

        // Remap all the restored prevpageid and nextpageid now that we have all the pages and their mappings
        $rs = $DB->get_recordset('cisalesson_pages', array('lessonid' => $this->task->get_activityid()),
                                 '', 'id, prevpageid, nextpageid');
        foreach ($rs as $page) {
            $page->prevpageid = (empty($page->prevpageid)) ? 0 : $this->get_mappingid('cisalesson_page', $page->prevpageid);
            $page->nextpageid = (empty($page->nextpageid)) ? 0 : $this->get_mappingid('cisalesson_page', $page->nextpageid);
            $DB->update_record('cisalesson_pages', $page);
        }
        $rs->close();

        // Remap all the restored 'jumpto' fields now that we have all the pages and their mappings
        $rs = $DB->get_recordset('cisalesson_answers', array('lessonid' => $this->task->get_activityid()),
                                 '', 'id, jumpto');
        foreach ($rs as $answer) {
            if ($answer->jumpto > 0) {
                $answer->jumpto = $this->get_mappingid('cisalesson_page', $answer->jumpto);
                $DB->update_record('cisalesson_answers', $answer);
            }
        }
        $rs->close();

        // Remap all the restored 'nextpageid' fields now that we have all the pages and their mappings.
        $rs = $DB->get_recordset('cisalesson_branch', array('lessonid' => $this->task->get_activityid()),
                                 '', 'id, nextpageid');
        foreach ($rs as $answer) {
            if ($answer->nextpageid > 0) {
                $answer->nextpageid = $this->get_mappingid('cisalesson_page', $answer->nextpageid);
                $DB->update_record('cisalesson_branch', $answer);
            }
        }
        $rs->close();

        // Remap all the restored 'nextpageid' fields for Cyber Range pages now that we have all the pages and their mappings.
        $rs = $DB->get_recordset('cisalesson_cyber', array('lessonid' => $this->task->get_activityid()),
                                 '', 'id, nextpageid');
        foreach ($rs as $answer) {
            if ($answer->nextpageid > 0) {
                $answer->nextpageid = $this->get_mappingid('cisalesson_page', $answer->nextpageid);
                $DB->update_record('cisalesson_cyber', $answer);
            }
        }
        $rs->close();

        // Replay the upgrade step 2015030301
        // to clean lesson answers that should be plain text.
        // 1 = CISALESSON_PAGE_SHORTANSWER, 8 = CISALESSON_PAGE_NUMERICAL, 20 = CISALESSON_PAGE_BRANCHTABLE, 25 = CISALESSON_PAGE_CYBERTABLE.

        $sql = 'SELECT a.*
                  FROM {cisalesson_answers} a
                  JOIN {cisalesson_pages} p ON p.id = a.pageid
                 WHERE a.answerformat <> :format
                   AND a.lessonid = :lessonid
                   AND p.qtype IN (1, 8, 20, 25)';
        $badanswers = $DB->get_recordset_sql($sql, array('lessonid' => $this->task->get_activityid(), 'format' => FORMAT_MOODLE));

        foreach ($badanswers as $badanswer) {
            // Strip tags from answer text and convert back the format to FORMAT_MOODLE.
            $badanswer->answer = strip_tags($badanswer->answer);
            $badanswer->answerformat = FORMAT_MOODLE;
            $DB->update_record('cisalesson_answers', $badanswer);
        }
        $badanswers->close();

        // Replay the upgrade step 2015032700.
        // Delete any orphaned lesson_branch record.
        if ($DB->get_dbfamily() === 'mysql') {
            $sql = "DELETE {cisalesson_branch}
                      FROM {cisalesson_branch}
                 LEFT JOIN {cisalesson_pages}
                        ON {cisalesson_branch}.pageid = {cisalesson_pages}.id
                     WHERE {cisalesson_pages}.id IS NULL";
        } else {
            $sql = "DELETE FROM {cisalesson_branch}
               WHERE NOT EXISTS (
                         SELECT 'x' FROM {cisalesson_pages}
                          WHERE {cisalesson_branch}.pageid = {cisalesson_pages}.id)";
        }
        $DB->execute($sql);

        // Replay the upgrade step 2015032700 for Cyber Range pages.
        // Delete any orphaned lesson_cyber record.
        if ($DB->get_dbfamily() === 'mysql') {
            $sql = "DELETE {cisalesson_cyber}
                      FROM {cisalesson_cyber}
                 LEFT JOIN {cisalesson_pages}
                        ON {cisalesson_cyber}.pageid = {cisalesson_pages}.id
                     WHERE {cisalesson_pages}.id IS NULL";
        } else {
            $sql = "DELETE FROM {cisalesson_cyber}
               WHERE NOT EXISTS (
                         SELECT 'x' FROM {cisalesson_pages}
                          WHERE {cisalesson_cyber}.pageid = {cisalesson_pages}.id)";
        }
        $DB->execute($sql);

    }
}
